# SCY Intelligence — CBT Practice Studio

Timed CBT practice exams for PHY102, MTH102, and STA111 with topic-level
feedback and a shared leaderboard.

## What's inside
- React + Vite + Tailwind frontend
- 295 questions across 3 courses (`src/data/questions.js`)
- Personal attempt history saved in the browser (`localStorage`)
- Shared leaderboard backed by **Vercel KV**, via `api/leaderboard.js`

## Run it locally
```bash
npm install
npm run dev
```
Note: the leaderboard API route needs a deployed Vercel KV store to actually
work. Locally, leaderboard reads/writes will just fail quietly (the rest of
the app — exams, scoring, topic breakdown — works fine without it).

## Deploy

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

### 2. Import into Vercel
Go to vercel.com → **Add New Project** → import your GitHub repo. Vercel
auto-detects Vite — no config changes needed. Click **Deploy**.

### 3. Set up Vercel KV (for the shared leaderboard)
1. In your Vercel project, go to the **Storage** tab.
2. Click **Create Database** → choose **KV**.
3. Connect it to this project when prompted.
4. Vercel automatically injects `KV_REST_API_URL` / `KV_REST_API_TOKEN` as
   environment variables — you don't need to copy/paste anything.
5. Redeploy (Vercel usually does this automatically after connecting a
   database; if not, trigger a redeploy from the Deployments tab).

That's it — the leaderboard at `/api/leaderboard` will start working once KV
is connected.

## Project structure
```
src/
  data/questions.js     question banks for all 3 courses
  components/theme.js   colors + pure helper functions
  components/UI.jsx     Logo, buttons, nav, particle background
  screens/              one file per screen (Home, Exam, Results, ...)
  lib/storage.js        localStorage + leaderboard fetch helpers
  App.jsx               routing/state
api/
  leaderboard.js        Vercel serverless function (Vercel KV)
public/
  logo.webp             SCY Intelligence logo
```

## Notes
- The leaderboard route stores a top-10 list per course as a single KV key
  (`leaderboard:PHY102`, etc.). Simple, but two people submitting at the
  exact same instant could in theory clobber each other — fine for casual
  use, not built for high concurrency.
- Exam length: 50 questions for PHY102/STA111, all 28 for MTH102 (its
  whole bank), with time scaled roughly to question count.
