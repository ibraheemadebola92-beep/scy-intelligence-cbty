import { C, fmtTime } from "../components/theme";
import { GoldButton } from "../components/UI";
import { Clock, ChevronLeft, ChevronRight, ListChecks } from "lucide-react";

export function Exam({ course, questions, currentIdx, setCurrentIdx, answers, setAnswers, timeLeft, onSubmitRequest }) {
  const q = questions[currentIdx];
  const answeredCount = Object.keys(answers).length;
  const low = timeLeft < 60;

  return (
    <div className="max-w-3xl mx-auto px-5 py-6">
      <div className="flex items-center justify-between mb-5">
        <div className="f-mono text-xs uppercase tracking-widest" style={{ color: C.slate }}>{course.code}</div>
        <div
          className={`f-mono font-bold text-lg flex items-center gap-2 ${low ? "scy-pulse" : ""}`}
          style={{ color: low ? C.copper : C.gold }}
        >
          <Clock size={16} /> {fmtTime(timeLeft)}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-6">
        {questions.map((_, i) => {
          const isAnswered = answers[i] !== undefined;
          const isCurrent = i === currentIdx;
          return (
            <button
              key={i}
              onClick={() => setCurrentIdx(i)}
              className="f-mono text-[11px] w-7 h-7 rounded flex items-center justify-center"
              style={{
                background: isCurrent ? C.gold : isAnswered ? "rgba(212,175,55,0.18)" : "transparent",
                color: isCurrent ? "#0a0a0b" : isAnswered ? C.gold : C.slate,
                border: `1px solid ${isCurrent ? C.gold : C.hair}`,
              }}
            >
              {i + 1}
            </button>
          );
        })}
      </div>

      <div className="f-mono text-xs mb-2" style={{ color: C.slate }}>
        Question {currentIdx + 1} of {questions.length} · {answeredCount} answered
      </div>
      <div className="rounded-xl p-6 mb-6" style={{ border: `1px solid ${C.hair}`, background: "rgba(255,255,255,0.02)" }}>
        <div className="f-body text-lg leading-relaxed mb-6" style={{ color: C.ivory }}>{q.q}</div>
        <div className="space-y-3">
          {q.options.map((opt, i) => {
            const selected = answers[currentIdx] === i;
            return (
              <button
                key={i}
                onClick={() => setAnswers((prev) => ({ ...prev, [currentIdx]: i }))}
                className="w-full text-left rounded-lg px-4 py-3 f-body text-sm flex gap-3 items-start"
                style={{
                  border: `1px solid ${selected ? C.gold : C.hair}`,
                  background: selected ? "rgba(212,175,55,0.1)" : "transparent",
                  color: C.ivory,
                }}
              >
                <span className="f-mono font-bold" style={{ color: selected ? C.gold : C.slate }}>
                  {String.fromCharCode(65 + i)}
                </span>
                <span>{opt}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <GoldButton variant="ghost" icon={ChevronLeft} disabled={currentIdx === 0} onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}>
          Prev
        </GoldButton>
        {currentIdx === questions.length - 1 ? (
          <GoldButton onClick={onSubmitRequest} icon={ListChecks}>Submit Exam</GoldButton>
        ) : (
          <GoldButton onClick={() => setCurrentIdx((i) => Math.min(questions.length - 1, i + 1))}>
            Next <ChevronRight size={18} />
          </GoldButton>
        )}
      </div>
    </div>
  );
}

export function SubmitModal({ answeredCount, total, onCancel, onConfirm }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-6" style={{ background: "rgba(0,0,0,0.7)" }}>
      <div className="rounded-xl p-6 max-w-sm w-full" style={{ background: C.void2, border: `1px solid ${C.hair}` }}>
        <div className="f-display font-bold text-lg mb-2" style={{ color: C.ivory }}>Submit exam?</div>
        <p className="f-body text-sm mb-6" style={{ color: C.slate }}>
          You answered {answeredCount} of {total} questions. Unanswered questions will be marked incorrect.
        </p>
        <div className="flex gap-3">
          <GoldButton variant="ghost" full onClick={onCancel}>Keep Going</GoldButton>
          <GoldButton full onClick={onConfirm}>Submit</GoldButton>
        </div>
      </div>
    </div>
  );
}
