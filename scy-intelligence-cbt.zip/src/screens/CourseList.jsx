import { COURSES } from "../data/questions";
import { C } from "../components/theme";

export default function CourseList({ setScreen, setActiveCourse }) {
  return (
    <div className="max-w-4xl mx-auto px-6 py-14">
      <h1 className="f-display font-bold text-3xl mb-2" style={{ color: C.ivory }}>Choose a course</h1>
      <p className="f-body text-sm mb-8" style={{ color: C.slate }}>Pick a course to start a timed practice exam.</p>
      <div className="grid sm:grid-cols-3 gap-5">
        {COURSES.map((c) => (
          <button
            key={c.id}
            onClick={() => { setActiveCourse(c); setScreen("instructions"); }}
            className="text-left rounded-xl p-6 transition-transform hover:-translate-y-1"
            style={{ border: `1px solid ${C.hair}`, background: "rgba(255,255,255,0.02)" }}
          >
            <div className="f-display font-bold text-3xl mb-3" style={{ color: C.gold }}>{c.glyph}</div>
            <div className="f-mono text-xs uppercase tracking-widest" style={{ color: C.slate }}>{c.code}</div>
            <div className="f-display font-bold text-lg mt-1" style={{ color: C.ivory }}>{c.title}</div>
            <div className="f-body text-sm mt-2" style={{ color: C.slate }}>{c.blurb}</div>
            <div className="f-mono text-[11px] mt-4" style={{ color: C.gold }}>{c.bank.length} questions in bank →</div>
          </button>
        ))}
      </div>
    </div>
  );
}
