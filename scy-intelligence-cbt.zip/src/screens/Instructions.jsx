import { C, getExamConfig } from "../components/theme";
import { GoldButton } from "../components/UI";
import { ChevronLeft } from "lucide-react";

export default function Instructions({ course, setScreen, onStart }) {
  const cfg = getExamConfig(course);
  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <button onClick={() => setScreen("courses")} className="f-mono text-xs flex items-center gap-1 mb-6" style={{ color: C.slate }}>
        <ChevronLeft size={14} /> Back to courses
      </button>
      <div className="f-display font-bold text-2xl mb-1" style={{ color: C.ivory }}>{course.code} — {course.title}</div>
      <p className="f-body text-sm mb-8" style={{ color: C.slate }}>Read the rules before you begin.</p>

      <div className="grid grid-cols-2 gap-4 mb-8">
        {[
          [cfg.total, "Questions"],
          [`${cfg.minutes}:00`, "Time Limit"],
          ["A–D", "Per Question"],
          ["1", "Point Each"],
        ].map(([v, l]) => (
          <div key={l} className="rounded-lg py-4 text-center" style={{ border: `1px solid ${C.hair}` }}>
            <div className="f-mono font-bold text-xl" style={{ color: C.gold }}>{v}</div>
            <div className="f-mono text-[10px] uppercase tracking-widest mt-1" style={{ color: C.slate }}>{l}</div>
          </div>
        ))}
      </div>

      <ul className="f-body text-sm space-y-2 mb-10" style={{ color: C.slate }}>
        <li>• Questions are pulled randomly from the {course.id} question bank — every attempt is different.</li>
        <li>• The exam auto-submits when the timer hits zero.</li>
        <li>• You can move freely between questions using the grid before submitting.</li>
        <li>• Your topic-level breakdown is shown right after you submit.</li>
      </ul>

      <GoldButton full onClick={onStart}>Begin Exam</GoldButton>
    </div>
  );
}
