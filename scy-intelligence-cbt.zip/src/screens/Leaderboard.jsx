import { useState, useEffect } from "react";
import { COURSES } from "../data/questions";
import { C } from "../components/theme";
import { fetchLeaderboard } from "../lib/storage";

export default function Leaderboard() {
  const [activeId, setActiveId] = useState(COURSES[0].id);
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const result = await fetchLeaderboard(activeId);
      if (!cancelled) {
        setData((prev) => ({ ...prev, [activeId]: result }));
        setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [activeId]);

  const entries = (data[activeId] || []).slice().sort((a, b) => b.percent - a.percent);

  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <h1 className="f-display font-bold text-3xl mb-2" style={{ color: C.ivory }}>Leaderboard</h1>
      <p className="f-body text-sm mb-8" style={{ color: C.slate }}>Top scores shared by everyone using this app.</p>

      <div className="flex gap-2 mb-6">
        {COURSES.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveId(c.id)}
            className="f-mono text-xs px-3 py-1.5 rounded-full uppercase tracking-widest"
            style={{
              background: activeId === c.id ? C.gold : "transparent",
              color: activeId === c.id ? "#0a0a0b" : C.slate,
              border: `1px solid ${activeId === c.id ? C.gold : C.hair}`,
            }}
          >
            {c.id}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="f-body text-sm" style={{ color: C.slate }}>Loading...</div>
      ) : entries.length === 0 ? (
        <div className="f-body text-sm" style={{ color: C.slate }}>No scores yet for this course — be the first.</div>
      ) : (
        <div className="space-y-2">
          {entries.map((e, i) => (
            <div key={i} className="flex items-center justify-between rounded-lg px-4 py-3" style={{ border: `1px solid ${C.hair}` }}>
              <div className="flex items-center gap-3">
                <div className="f-mono font-bold w-6" style={{ color: i < 3 ? C.gold : C.slate }}>{i + 1}</div>
                <div className="f-body text-sm" style={{ color: C.ivory }}>{e.name}</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="f-mono text-xs" style={{ color: C.slate }}>{e.score}/{e.total}</div>
                <div className="f-mono font-bold text-sm" style={{ color: C.gold }}>{e.percent}%</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
