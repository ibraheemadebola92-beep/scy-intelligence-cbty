import { C, fmtTime } from "../components/theme";
import { GoldButton } from "../components/UI";
import { CheckCircle2, RotateCcw, Trophy } from "lucide-react";

export default function Results({ course, questions, answers, timeUsed, setScreen, onRetake, leaderboardSaved, onSaveLeaderboard, savingName, setSavingName }) {
  const total = questions.length;
  let correctCount = 0;
  const topicMap = {};
  questions.forEach((q, i) => {
    const isCorrect = answers[i] === q.correct;
    if (isCorrect) correctCount++;
    if (!topicMap[q.topic]) topicMap[q.topic] = { correct: 0, total: 0 };
    topicMap[q.topic].total++;
    if (isCorrect) topicMap[q.topic].correct++;
  });
  const percent = Math.round((correctCount / total) * 100);
  const topics = Object.entries(topicMap).sort((a, b) => a[1].correct / a[1].total - b[1].correct / b[1].total);

  return (
    <div className="max-w-2xl mx-auto px-6 py-14">
      <div className="text-center mb-10">
        <div className="f-mono text-xs uppercase tracking-widest mb-2" style={{ color: C.slate }}>{course.code} Result</div>
        <div className="f-display font-bold text-6xl" style={{ color: percent >= 50 ? C.gold : C.copper }}>{percent}%</div>
        <div className="f-body text-sm mt-2" style={{ color: C.slate }}>
          {correctCount} / {total} correct · {fmtTime(timeUsed)} used
        </div>
      </div>

      <div className="mb-10">
        <div className="f-display font-bold text-sm mb-4" style={{ color: C.ivory }}>Topic breakdown</div>
        <div className="space-y-3">
          {topics.map(([topic, t]) => {
            const pct = Math.round((t.correct / t.total) * 100);
            return (
              <div key={topic}>
                <div className="flex justify-between f-body text-xs mb-1" style={{ color: C.slate }}>
                  <span>{topic}</span>
                  <span className="f-mono">{t.correct}/{t.total}</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${pct}%`, background: pct >= 60 ? `linear-gradient(90deg, ${C.gold}, ${C.goldBright})` : C.copper }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {!leaderboardSaved ? (
        <div className="rounded-lg p-4 mb-6" style={{ border: `1px solid ${C.hair}` }}>
          <div className="f-body text-sm mb-3" style={{ color: C.ivory }}>Post this score to the leaderboard?</div>
          <div className="flex gap-2">
            <input
              value={savingName}
              onChange={(e) => setSavingName(e.target.value)}
              placeholder="Your name"
              maxLength={24}
              className="flex-1 f-body text-sm rounded-md px-3 py-2 outline-none"
              style={{ background: "rgba(255,255,255,0.04)", color: C.ivory, border: `1px solid ${C.hair}` }}
            />
            <GoldButton onClick={() => onSaveLeaderboard(percent, correctCount, total)} disabled={!savingName.trim()}>
              Save
            </GoldButton>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 f-body text-sm mb-6" style={{ color: C.gold }}>
          <CheckCircle2 size={16} /> Saved to leaderboard
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <GoldButton variant="ghost" icon={RotateCcw} onClick={onRetake}>Retake</GoldButton>
        <GoldButton icon={Trophy} onClick={() => setScreen("leaderboard")}>Leaderboard</GoldButton>
      </div>
      <button onClick={() => setScreen("courses")} className="w-full text-center f-mono text-xs mt-5" style={{ color: C.slate }}>
        ← Back to all courses
      </button>
    </div>
  );
}
