import { COURSES } from "../data/questions";
import { C } from "../components/theme";
import { Logo, GoldButton, ParticleField } from "../components/UI";
import { BookOpen, Trophy } from "lucide-react";

export default function Home({ setScreen }) {
  const totalQuestions = COURSES.reduce((s, c) => s + c.bank.length, 0);
  return (
    <div>
      <section className="relative overflow-hidden" style={{ minHeight: "78vh" }}>
        <ParticleField intensity={1.1} />
        <div
          className="absolute inset-0"
          style={{ background: `radial-gradient(ellipse at 50% 30%, transparent 0%, ${C.void} 75%)` }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6 pt-20 pb-24 text-center flex flex-col items-center">
          <Logo size={120} />
          <h1 className="f-display font-bold mt-8 text-4xl sm:text-5xl leading-tight" style={{ color: C.ivory }}>
            Turn exam chaos<br />into <span style={{ color: C.gold }}>mastery</span>.
          </h1>
          <p className="f-body mt-5 max-w-xl text-base sm:text-lg" style={{ color: C.slate }}>
            The SCY Intelligence CBT Practice Studio — real past-question banks, timed mock exams,
            and topic-level feedback so you walk into the real thing already calm.
          </p>
          <div className="flex flex-wrap gap-3 mt-8 justify-center">
            <GoldButton onClick={() => setScreen("courses")} icon={BookOpen}>
              Start Practicing
            </GoldButton>
            <GoldButton onClick={() => setScreen("leaderboard")} variant="ghost" icon={Trophy}>
              View Leaderboard
            </GoldButton>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-14 w-full max-w-md">
            {[
              [COURSES.length, "Courses"],
              [totalQuestions, "Questions"],
              ["50", "Per Exam"],
            ].map(([num, label]) => (
              <div key={label} className="rounded-lg py-4" style={{ border: `1px solid ${C.hair}`, background: "rgba(255,255,255,0.02)" }}>
                <div className="f-mono font-bold text-2xl" style={{ color: C.gold }}>{num}</div>
                <div className="f-mono text-[10px] uppercase tracking-widest mt-1" style={{ color: C.slate }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-16">
        <h2 className="f-display font-bold text-2xl text-center mb-10" style={{ color: C.ivory }}>
          Built for how you actually study
        </h2>
        <div className="grid sm:grid-cols-3 gap-5">
          {[
            ["Real past questions", "Pulled straight from compiled course CA/CBT banks, not generic filler."],
            ["Timed, randomized", "Every attempt pulls a fresh shuffled set so you cannot just memorize the order."],
            ["Topic-level feedback", "See exactly which topics are weak instead of one flat percentage."],
          ].map(([t, d]) => (
            <div key={t} className="rounded-lg p-5" style={{ border: `1px solid ${C.hair}`, background: "rgba(255,255,255,0.02)" }}>
              <div className="f-display font-bold text-sm mb-2" style={{ color: C.gold }}>{t}</div>
              <div className="f-body text-sm leading-relaxed" style={{ color: C.slate }}>{d}</div>
            </div>
          ))}
        </div>
      </section>

      <footer className="text-center py-8 f-mono text-[11px] uppercase tracking-widest" style={{ color: C.slate }}>
        SCY Intelligence — Intelligent Solutions. Limitless Possibilities.
      </footer>
    </div>
  );
}
