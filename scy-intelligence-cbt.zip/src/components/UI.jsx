import { useEffect, useRef } from "react";
import { C } from "./theme";

export function Fonts() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=IBM+Plex+Mono:wght@400;500&family=Inter:wght@400;500;600&display=swap');
      .f-display { font-family: 'Space Grotesk', sans-serif; }
      .f-mono { font-family: 'IBM Plex Mono', monospace; }
      .f-body { font-family: 'Inter', sans-serif; }
      @keyframes scy-pulse { 0%,100% { opacity: 0.5; } 50% { opacity: 1; } }
      .scy-pulse { animation: scy-pulse 2.2s ease-in-out infinite; }
      @media (prefers-reduced-motion: reduce) {
        .scy-pulse { animation: none; }
      }
    `}</style>
  );
}

// Signature visual: a particle field where the right half settles into an
// ordered grid and the left half drifts chaotically — exam chaos resolving into mastery.
export function ParticleField({ intensity = 1 }) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf, w, h, particles = [];

    function init() {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);

      particles = [];
      const cols = Math.max(6, Math.floor(14 * intensity));
      const rows = Math.max(6, Math.floor(10 * intensity));
      for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
          const ox = w * 0.5 + (i / cols) * w * 0.48 + w * 0.02;
          const oy = (j / rows) * h;
          particles.push({ x: ox, y: oy, ox, oy, vx: 0, vy: 0, ordered: true });
        }
      }
      const chaosCount = Math.floor(cols * rows * 0.75);
      for (let k = 0; k < chaosCount; k++) {
        particles.push({
          x: Math.random() * w * 0.5,
          y: Math.random() * h,
          ox: 0, oy: 0,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          ordered: false,
        });
      }
    }

    function step() {
      ctx.clearRect(0, 0, w, h);
      particles.forEach((p) => {
        if (p.ordered) {
          p.x += (p.ox - p.x) * 0.04;
          p.y += (p.oy - p.y) * 0.04;
        } else {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > w * 0.55) p.vx *= -1;
          if (p.y < 0 || p.y > h) p.vy *= -1;
        }
        ctx.beginPath();
        ctx.fillStyle = p.ordered ? "rgba(212,175,55,0.5)" : "rgba(184,115,59,0.4)";
        ctx.arc(p.x, p.y, 1.4, 0, Math.PI * 2);
        ctx.fill();
      });
      if (!reduced) raf = requestAnimationFrame(step);
    }

    init();
    step();
    const onResize = () => init();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [intensity]);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />;
}

export function Logo({ size = 40, withWordmark = false }) {
  return (
    <div className="flex items-center gap-3">
      <img src="/logo.webp" alt="SCY Intelligence" style={{ width: size, height: size, objectFit: "contain" }} />
      {withWordmark && (
        <div className="leading-tight">
          <div className="f-display font-bold tracking-wide" style={{ color: C.ivory, fontSize: size * 0.34 }}>
            SCY <span style={{ color: C.gold }}>INTELLIGENCE</span>
          </div>
          <div className="f-mono uppercase tracking-[0.2em]" style={{ color: C.slate, fontSize: size * 0.16 }}>
            CBT Practice Studio
          </div>
        </div>
      )}
    </div>
  );
}

export function GoldButton({ children, onClick, full, variant = "solid", icon: Icon, disabled }) {
  const base = "f-display font-bold tracking-wide rounded-md px-6 py-3 inline-flex items-center justify-center gap-2 transition-transform active:scale-[0.98]";
  const style =
    variant === "solid"
      ? { background: `linear-gradient(135deg, ${C.goldBright}, ${C.gold})`, color: "#0a0a0b" }
      : { background: "transparent", color: C.gold, border: `1px solid ${C.hair}` };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${full ? "w-full" : ""} ${disabled ? "opacity-40 cursor-not-allowed" : "hover:brightness-110"}`}
      style={style}
    >
      {Icon && <Icon size={18} />}
      {children}
    </button>
  );
}

export function TopNav({ screen, setScreen }) {
  return (
    <div className="sticky top-0 z-30 backdrop-blur-md border-b" style={{ borderColor: C.hair, background: "rgba(10,10,11,0.75)" }}>
      <div className="max-w-5xl mx-auto px-5 py-3 flex items-center justify-between">
        <button onClick={() => setScreen("home")} className="flex items-center gap-2">
          <Logo size={34} />
          <span className="f-display font-bold text-sm tracking-wide hidden sm:inline" style={{ color: C.ivory }}>
            SCY <span style={{ color: C.gold }}>INTELLIGENCE</span>
          </span>
        </button>
        <div className="flex items-center gap-4 f-mono text-xs uppercase tracking-widest">
          <button onClick={() => setScreen("courses")} className={screen === "courses" ? "" : "opacity-60"} style={{ color: C.gold }}>
            Courses
          </button>
          <button onClick={() => setScreen("leaderboard")} className={screen === "leaderboard" ? "" : "opacity-60"} style={{ color: C.gold }}>
            Leaderboard
          </button>
        </div>
      </div>
    </div>
  );
}
