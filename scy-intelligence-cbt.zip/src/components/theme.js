export const C = {
  void: "#0a0a0b",
  void2: "#111113",
  gold: "#D4AF37",
  goldBright: "#F2D785",
  copper: "#B8733B",
  ivory: "#ECE8DF",
  slate: "#8C8A8A",
  hair: "rgba(212,175,55,0.16)",
};

export function shuffleArr(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function sample(arr, n) {
  return shuffleArr(arr).slice(0, Math.min(n, arr.length));
}

export function fmtTime(s) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

export function getExamConfig(course) {
  const total = Math.min(50, course.bank.length);
  const minutes = Math.max(12, Math.round(total * 0.6));
  return { total, minutes };
}
