import { useState, useEffect } from "react";
import { C } from "./components/theme";
import { Fonts, TopNav } from "./components/UI";
import { shuffleArr, sample, getExamConfig } from "./components/theme";
import { getLocal, setLocal, postLeaderboard } from "./lib/storage";

import Home from "./screens/Home";
import CourseList from "./screens/CourseList";
import Instructions from "./screens/Instructions";
import { Exam, SubmitModal } from "./screens/Exam";
import Results from "./screens/Results";
import Leaderboard from "./screens/Leaderboard";

export default function App() {
  const [screen, setScreen] = useState("home");
  const [activeCourse, setActiveCourse] = useState(null);
  const [examQuestions, setExamQuestions] = useState([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [examStartedAt, setExamStartedAt] = useState(null);
  const [timeUsed, setTimeUsed] = useState(0);
  const [leaderboardSaved, setLeaderboardSaved] = useState(false);
  const [savingName, setSavingName] = useState("");

  useEffect(() => {
    const name = getLocal("profile:name", "");
    if (name) setSavingName(name);
  }, []);

  useEffect(() => {
    if (screen !== "exam") return;
    if (timeLeft <= 0) {
      handleSubmit();
      return;
    }
    const t = setTimeout(() => setTimeLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, timeLeft]);

  function startExam() {
    const cfg = getExamConfig(activeCourse);
    const chosen = sample(activeCourse.bank, cfg.total);
    const prepped = chosen.map((q) => {
      const order = shuffleArr(q.options.map((_, i) => i));
      return {
        q: q.q,
        topic: q.topic,
        options: order.map((i) => q.options[i]),
        correct: order.indexOf(q.correct),
      };
    });
    setExamQuestions(prepped);
    setCurrentIdx(0);
    setAnswers({});
    setTimeLeft(cfg.minutes * 60);
    setExamStartedAt(Date.now());
    setLeaderboardSaved(false);
    setScreen("exam");
  }

  function handleSubmit() {
    const used = examStartedAt ? Math.round((Date.now() - examStartedAt) / 1000) : 0;
    setTimeUsed(used);
    setShowSubmitModal(false);
    saveHistoryEntry(used);
    setScreen("results");
  }

  function saveHistoryEntry(used) {
    if (!activeCourse) return;
    let correct = 0;
    examQuestions.forEach((q, i) => { if (answers[i] === q.correct) correct++; });
    const percent = Math.round((correct / examQuestions.length) * 100);
    const entry = { date: new Date().toISOString(), score: correct, total: examQuestions.length, percent, timeUsed: used };
    const current = getLocal("history:" + activeCourse.id, []);
    setLocal("history:" + activeCourse.id, [entry, ...current].slice(0, 20));
  }

  async function handleSaveLeaderboard(percent, score, total) {
    if (!activeCourse || !savingName.trim()) return;
    setLocal("profile:name", savingName.trim());
    const result = await postLeaderboard(activeCourse.id, { name: savingName.trim(), score, total, percent });
    if (result) setLeaderboardSaved(true);
  }

  let body;
  if (screen === "home") body = <Home setScreen={setScreen} />;
  else if (screen === "courses") body = <CourseList setScreen={setScreen} setActiveCourse={setActiveCourse} />;
  else if (screen === "instructions" && activeCourse) body = <Instructions course={activeCourse} setScreen={setScreen} onStart={startExam} />;
  else if (screen === "exam" && examQuestions.length > 0)
    body = (
      <Exam
        course={activeCourse}
        questions={examQuestions}
        currentIdx={currentIdx}
        setCurrentIdx={setCurrentIdx}
        answers={answers}
        setAnswers={setAnswers}
        timeLeft={timeLeft}
        onSubmitRequest={() => setShowSubmitModal(true)}
      />
    );
  else if (screen === "results" && activeCourse)
    body = (
      <Results
        course={activeCourse}
        questions={examQuestions}
        answers={answers}
        timeUsed={timeUsed}
        setScreen={setScreen}
        onRetake={startExam}
        leaderboardSaved={leaderboardSaved}
        onSaveLeaderboard={handleSaveLeaderboard}
        savingName={savingName}
        setSavingName={setSavingName}
      />
    );
  else if (screen === "leaderboard") body = <Leaderboard />;
  else body = <Home setScreen={setScreen} />;

  return (
    <div className="min-h-screen f-body" style={{ background: C.void, color: C.ivory }}>
      <Fonts />
      <TopNav screen={screen} setScreen={setScreen} />
      {body}
      {showSubmitModal && (
        <SubmitModal
          answeredCount={Object.keys(answers).length}
          total={examQuestions.length}
          onCancel={() => setShowSubmitModal(false)}
          onConfirm={handleSubmit}
        />
      )}
    </div>
  );
}
